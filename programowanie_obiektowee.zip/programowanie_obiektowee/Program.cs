﻿using programowanie_obiektowee.Klasy;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programowanie_obiektowee
{
    class Program
    {
        static void Main(string[] args)
        {
        
   




            Console.ReadLine();
        }
    }
}
