﻿namespace toDoListBef.Kontrolki
{
    partial class RegisterControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnCofnij = new System.Windows.Forms.Button();
            this.btnZarejestruj = new System.Windows.Forms.Button();
            this.lblImie = new System.Windows.Forms.Label();
            this.lblLogin = new System.Windows.Forms.Label();
            this.lblHaslo = new System.Windows.Forms.Label();
            this.lblPowtorzHaslo = new System.Windows.Forms.Label();
            this.tbImie = new System.Windows.Forms.TextBox();
            this.tbLogin = new System.Windows.Forms.TextBox();
            this.tbHaslo = new System.Windows.Forms.TextBox();
            this.tbPowtorzHasloWalidacja = new System.Windows.Forms.TextBox();
            this.lblImieWalidacja = new System.Windows.Forms.Label();
            this.lblLoginWalidacja = new System.Windows.Forms.Label();
            this.lblHasloWalidacja = new System.Windows.Forms.Label();
            this.lblPowtorzHasloWalidacja = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(253, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(244, 66);
            this.label1.TabIndex = 0;
            this.label1.Text = "Rejestraja";
            // 
            // btnCofnij
            // 
            this.btnCofnij.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(120)))), ((int)(((byte)(242)))));
            this.btnCofnij.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCofnij.FlatAppearance.BorderSize = 0;
            this.btnCofnij.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCofnij.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnCofnij.Location = new System.Drawing.Point(0, 0);
            this.btnCofnij.Name = "btnCofnij";
            this.btnCofnij.Size = new System.Drawing.Size(163, 56);
            this.btnCofnij.TabIndex = 1;
            this.btnCofnij.Text = "Cofnij";
            this.btnCofnij.UseVisualStyleBackColor = false;
           
            // 
            // btnZarejestruj
            // 
            this.btnZarejestruj.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(120)))), ((int)(((byte)(242)))));
            this.btnZarejestruj.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnZarejestruj.FlatAppearance.BorderSize = 0;
            this.btnZarejestruj.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnZarejestruj.Font = new System.Drawing.Font("Calibri", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnZarejestruj.Location = new System.Drawing.Point(0, 555);
            this.btnZarejestruj.Name = "btnZarejestruj";
            this.btnZarejestruj.Size = new System.Drawing.Size(500, 82);
            this.btnZarejestruj.TabIndex = 2;
            this.btnZarejestruj.Text = "Zarejestruj";
            this.btnZarejestruj.UseVisualStyleBackColor = false;
           
            // 
            // lblImie
            // 
            this.lblImie.AutoSize = true;
            this.lblImie.Font = new System.Drawing.Font("Calibri", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblImie.Location = new System.Drawing.Point(107, 133);
            this.lblImie.Name = "lblImie";
            this.lblImie.Size = new System.Drawing.Size(49, 23);
            this.lblImie.TabIndex = 3;
            this.lblImie.Text = "Imię:";
            // 
            // lblLogin
            // 
            this.lblLogin.AutoSize = true;
            this.lblLogin.Font = new System.Drawing.Font("Calibri", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblLogin.Location = new System.Drawing.Point(107, 233);
            this.lblLogin.Name = "lblLogin";
            this.lblLogin.Size = new System.Drawing.Size(56, 23);
            this.lblLogin.TabIndex = 4;
            this.lblLogin.Text = "Login:";
            // 
            // lblHaslo
            // 
            this.lblHaslo.AutoSize = true;
            this.lblHaslo.Font = new System.Drawing.Font("Calibri", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblHaslo.Location = new System.Drawing.Point(97, 326);
            this.lblHaslo.Name = "lblHaslo";
            this.lblHaslo.Size = new System.Drawing.Size(59, 23);
            this.lblHaslo.TabIndex = 5;
            this.lblHaslo.Text = "Hasło:";
            // 
            // lblPowtorzHaslo
            // 
            this.lblPowtorzHaslo.AutoSize = true;
            this.lblPowtorzHaslo.Font = new System.Drawing.Font("Calibri", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblPowtorzHaslo.Location = new System.Drawing.Point(35, 425);
            this.lblPowtorzHaslo.Name = "lblPowtorzHaslo";
            this.lblPowtorzHaslo.Size = new System.Drawing.Size(128, 23);
            this.lblPowtorzHaslo.TabIndex = 6;
            this.lblPowtorzHaslo.Text = "Powtórz Hasło:";
            // 
            // tbImie
            // 
            this.tbImie.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbImie.Location = new System.Drawing.Point(176, 116);
            this.tbImie.Multiline = true;
            this.tbImie.Name = "tbImie";
            this.tbImie.Size = new System.Drawing.Size(198, 40);
            this.tbImie.TabIndex = 7;
            // 
            // tbLogin
            // 
            this.tbLogin.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbLogin.Location = new System.Drawing.Point(176, 216);
            this.tbLogin.Multiline = true;
            this.tbLogin.Name = "tbLogin";
            this.tbLogin.Size = new System.Drawing.Size(198, 40);
            this.tbLogin.TabIndex = 8;
            // 
            // tbHaslo
            // 
            this.tbHaslo.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbHaslo.Location = new System.Drawing.Point(176, 309);
            this.tbHaslo.Multiline = true;
            this.tbHaslo.Name = "tbHaslo";
            this.tbHaslo.Size = new System.Drawing.Size(198, 40);
            this.tbHaslo.TabIndex = 9;
            // 
            // tbPowtorzHasloWalidacja
            // 
            this.tbPowtorzHasloWalidacja.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbPowtorzHasloWalidacja.Location = new System.Drawing.Point(176, 408);
            this.tbPowtorzHasloWalidacja.Multiline = true;
            this.tbPowtorzHasloWalidacja.Name = "tbPowtorzHasloWalidacja";
            this.tbPowtorzHasloWalidacja.Size = new System.Drawing.Size(198, 40);
            this.tbPowtorzHasloWalidacja.TabIndex = 10;
            // 
            // lblImieWalidacja
            // 
            this.lblImieWalidacja.AutoSize = true;
            this.lblImieWalidacja.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblImieWalidacja.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.lblImieWalidacja.Location = new System.Drawing.Point(176, 159);
            this.lblImieWalidacja.Name = "lblImieWalidacja";
            this.lblImieWalidacja.Size = new System.Drawing.Size(142, 19);
            this.lblImieWalidacja.TabIndex = 11;
            this.lblImieWalidacja.Text = "labelka na walidacje";
            // 
            // lblLoginWalidacja
            // 
            this.lblLoginWalidacja.AutoSize = true;
            this.lblLoginWalidacja.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblLoginWalidacja.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.lblLoginWalidacja.Location = new System.Drawing.Point(176, 259);
            this.lblLoginWalidacja.Name = "lblLoginWalidacja";
            this.lblLoginWalidacja.Size = new System.Drawing.Size(142, 19);
            this.lblLoginWalidacja.TabIndex = 12;
            this.lblLoginWalidacja.Text = "labelka na walidacje";
            // 
            // lblHasloWalidacja
            // 
            this.lblHasloWalidacja.AutoSize = true;
            this.lblHasloWalidacja.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblHasloWalidacja.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.lblHasloWalidacja.Location = new System.Drawing.Point(176, 352);
            this.lblHasloWalidacja.Name = "lblHasloWalidacja";
            this.lblHasloWalidacja.Size = new System.Drawing.Size(142, 19);
            this.lblHasloWalidacja.TabIndex = 13;
            this.lblHasloWalidacja.Text = "labelka na walidacje";
            // 
            // lblPowtorzHasloWalidacja
            // 
            this.lblPowtorzHasloWalidacja.AutoSize = true;
            this.lblPowtorzHasloWalidacja.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblPowtorzHasloWalidacja.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.lblPowtorzHasloWalidacja.Location = new System.Drawing.Point(176, 451);
            this.lblPowtorzHasloWalidacja.Name = "lblPowtorzHasloWalidacja";
            this.lblPowtorzHasloWalidacja.Size = new System.Drawing.Size(142, 19);
            this.lblPowtorzHasloWalidacja.TabIndex = 14;
            this.lblPowtorzHasloWalidacja.Text = "labelka na walidacje";
            // 
            // RegisterControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.Controls.Add(this.lblPowtorzHasloWalidacja);
            this.Controls.Add(this.lblHasloWalidacja);
            this.Controls.Add(this.lblLoginWalidacja);
            this.Controls.Add(this.lblImieWalidacja);
            this.Controls.Add(this.tbPowtorzHasloWalidacja);
            this.Controls.Add(this.tbHaslo);
            this.Controls.Add(this.tbLogin);
            this.Controls.Add(this.tbImie);
            this.Controls.Add(this.lblPowtorzHaslo);
            this.Controls.Add(this.lblHaslo);
            this.Controls.Add(this.lblLogin);
            this.Controls.Add(this.lblImie);
            this.Controls.Add(this.btnZarejestruj);
            this.Controls.Add(this.btnCofnij);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Calibri", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(233)))), ((int)(((byte)(233)))));
            this.Name = "RegisterControl";
            this.Size = new System.Drawing.Size(500, 640);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnCofnij;
        private System.Windows.Forms.Button btnZarejestruj;
        private System.Windows.Forms.Label lblImie;
        private System.Windows.Forms.Label lblLogin;
        private System.Windows.Forms.Label lblHaslo;
        private System.Windows.Forms.Label lblPowtorzHaslo;
        private System.Windows.Forms.TextBox tbImie;
        private System.Windows.Forms.TextBox tbLogin;
        private System.Windows.Forms.TextBox tbHaslo;
        private System.Windows.Forms.TextBox tbPowtorzHasloWalidacja;
        private System.Windows.Forms.Label lblImieWalidacja;
        private System.Windows.Forms.Label lblLoginWalidacja;
        private System.Windows.Forms.Label lblHasloWalidacja;
        private System.Windows.Forms.Label lblPowtorzHasloWalidacja;
    }
}
